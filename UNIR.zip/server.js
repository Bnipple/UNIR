import mysql from "mysql";
import { createServer } from "http";
import url from "url";
import query from "querystring";

const HOST = "localhost"; 
const PORT = "5500";

const server = createServer((req, res) => {
  // set res header
  res.setHeader("Access-Control-Allow-Origin", "*");
  res.setHeader("Access-Control-Allow-Headers", "X-Rquested-With");
  res.setHeader("Access-Control-Allow-Methods", "PUT,POST,GET,DELETE,OPTIONS");
  res.setHeader("X-Powered-By", "3.2.1");
  res.setHeader("Content-Type", "application/json;charset=utf-8");

  // mysql connection
  var connection = mysql.createConnection({
    host: "localhost",
    user: "root",
    password: "",
    database: "unir",
  });

  connection.connect();

  console.log("server is working...111", req.url);

  // reponse to client
  // /login?xx=xx&,...
  // [/login, xxx=xx...]
  switch (req.url.split("?")[0]) {
    //get data from the login interface
    case "/login": {
      const paramObj = getSearchParams(req.url);
      connection.query(
        `SELECT * from user where uname='${paramObj.uname}'`,
        function (error, results, fields) {
          // if there is a error,then throw the error
          if (error) {
            res.end(JSON.stringify({ err: -1 }));
          } else {
            // sql request is correct
            if (!results[0]) {
              // the user does not exist,so we insert the user information
              const { uname, password } = paramObj;
              const addSql = `INSERT INTO user(uname,password) VALUES('${uname}','${password}')`;
              //check the error again
              connection.query(addSql, (err, resp) => {
                if (!err) {
                  res.end(JSON.stringify({ uid: resp.insertId, uname }));
                }
              });
            } else {
              // the uname is correct,then check the password
              const { uid, uname, password } = results[0];
              // const uid = results[0].uid;

              if (password === paramObj.password) {
                // login successfully
                res.end(JSON.stringify({ uid, uname }));
              } else {
                res.end(JSON.stringify({ err: -1, msg: "the password is wrong" }));
              }
            }
          }
        }
      );

      break;
    }

    case "/stafflogin": {
      //get the staff name and password
      const params = url.parse(req.url, true);
      const { uname, password } = params.query;

      connection.query(
        `SELECT staff_name, password from staff where staff_name='${uname}' and password='${password}'`,
        function (error, results, fields) {
          if (error) {
            res.end(JSON.stringify({ err: -1 }));
          } else {
            if (results[0]) {
              res.end(JSON.stringify({ err: 200, msg: "Successfully login!" }));
            } else {
             res.end(JSON.stringify({ err: -1, msg: "Password is wrong!" }));
            }
          }
        }
      );
      break;
    }

    case "/addevent": {
      var postdata = "";
      // Once the listener is added, the readable stream fires the 'data' event
      req.addListener("data", function (chunk) {
        postdata += chunk;
      });
      // indicates that the full body has been obtained
      req.addListener("end", function () {
        // string to object
        var params = query.parse(postdata);
        const { eventname, place, date, description, type, uid, img } = params;
        const addSql = `INSERT INTO event (event_name,Place,date,description,type,uid,img) VALUES('${eventname}','${place}','${date}','${description}','${type}','${uid}','${img}')`;

        connection.query(addSql, (err, resp) => {
          if (!err) {
            res.end(JSON.stringify({ err: 200, msg: "Successfully submited!" }));
          } 
        });
      });
    }

    case "/eventList": {
      connection.query(
        `SELECT * from event LEFT JOIN user ON event.uid=user.uid`,
        function (error, results, fields) {
          if (error) {
            res.end(JSON.stringify({ err: -1 }));
          } else {
            if (results) {
              res.end(JSON.stringify({ err: 200, msg: results }));
            }
          }
        }
      );
      break;
    }

    // get the data of the  user table
    case "/getusers": {
      connection.query(`SELECT * from user`, function (error, results, fields) {
        if (error) {
          res.end(JSON.stringify({ err: -1 }));
        } else {
          if (results) {
            res.end(JSON.stringify({ err: 200, msg: results }));
          }
        }
      });
      break;
    }

    // get the data of the event table
    case "/getevents": {
      connection.query(
        `SELECT * from event LEFT JOIN user ON event.uid=user.uid`,
        function (error, results, fields) {
          if (error) {
            res.end(JSON.stringify({ err: -1 }));
          } else {
            if (results) {
              res.end(JSON.stringify({ err: 200, msg: results }));
            }
          }
        }
      );
      break;
    }

    // get the data of the staff table
    case "/getstaffs": {
      connection.query(
        `SELECT * from staff`,
        function (error, results, fields) {
          if (error) {
            res.end(JSON.stringify({ err: -1 }));
          } else {
            if (results) {
              res.end(JSON.stringify({ err: 200, msg: results }));
            }
          }
        }
      );
      break;
    }

    // when user delete the data of user table
    case "/delUserById": {
      const { uid } = getSearchParams(req.url);
      connection.query(
        `DELETE FROM user WHERE uid=${uid}`,
        function (error, results, fields) {
          if (error) {
            res.end(JSON.stringify({ err: -1 }));
          } else {
            if (results) {
              res.end(JSON.stringify({ err: 200, msg: "Successfully deleted" }));
            }
          }
        }
      );
      break;
    }

    // when user delete the data of event table
    case "/delEventById": {
      const { event_name } = getSearchParams(req.url);
      connection.query(
        `DELETE FROM event WHERE event_name=${event_name}`,
        function (error, results, fields) {
          if (error) {
            res.end(JSON.stringify({ err: -1 }));
          } else {
            if (results) {
              res.end(JSON.stringify({ err: 200, msg: "Successfully deleted" }));
            }
          }
        }
      );
      break;
    }

    // when user delete the data of staff table
    case "/delStaffById": {
      const { staffId } = getSearchParams(req.url);
      connection.query(
        `DELETE FROM staff WHERE staff_id=${staffId}`,
        function (error, results, fields) {
          if (error) {
            res.end(JSON.stringify({ err: -1 }));
          } else {
            if (results) {
              res.end(JSON.stringify({ err: 200, msg: "Successfully deleted" }));
            }
          }
        }
      );
      break;
    }
  }
});

server.listen(PORT, HOST, (error) => {
  if (error) {
    console.log("Something wrong: ", error);
    return;
  }

  console.log(`server is listening on http://${HOST}:${PORT} ...`);
});

// url = ?userid=99&name=zs&age=99
function getSearchParams(url) {
  // [undefined, userid=99&name=zs&age=99]
  const paramsStr = url.split("?")[1]; // userid=99&name=zs&age=99
  const params = paramsStr.split("&"); // [userid=99, name=zs, age=99]
  const paramObj = {};

  // [userid=99, name=zs, age=99]
  params.forEach((item) => {
    const p = item.split("=");
    paramObj[p[0]] = p[1]; // paramObj[userid] = 99
  });
  /**
   * {
   *  userid: 99,
   *  name: zs,
   *  age: 99
   * }
   */
  return paramObj;
}
