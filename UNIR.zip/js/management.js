let users, events, staffs;
//creat three arrays to storage the value of tables.
getusers();
getevents();
getstaffs();

//add a selector to the event_list container
const $eventList = document.querySelector(".event_list");
$eventList.innerHTML = "";
//logout event
const logout = document.querySelector(".logout");
  logout.addEventListener("click", function () {
    location = "staff_login.html";
  });

  // add event to the 'event_list' container
document.querySelector(".event_list").addEventListener("click", function (e) {
  const target = e.target;
  //Create a XMLHttpRequest object
  //XMLHttpRequest is used to exchange data with the server in the background
  const xhr = new XMLHttpRequest();
  //Check in which table the user clicked the Delete button
  switch (target.className) {
    case "delUser":
      //creat a HTTP request
      xhr.open(
        "get",
        `http://localhost:5500/delUserById?uid=${target.dataset["id"]}`
      );
      //Bind a response status event listener function
      xhr.onreadystatechange = function () {
        //4:Finish and the data is received
        if (xhr.readyState == 4) {
          //set the res equal to the value from the url
          const res = JSON.parse(xhr.responseText);
          if (res) {
            //use filter to instead of the delete
            //lazy..
            users = users.filter((u) => u.uid != target.dataset["id"]);
            //Reorganize into arrays
            generatorUserHtml(users);
          }
        }
      };
      //send the request
      xhr.send();
      break;
    //do the same in the event table
    case "delEvent":
      xhr.open(
        "get",
        `http://localhost:5500/delEventById?event_name=${target.dataset["eventName"]}`
      );
      xhr.onreadystatechange = function () {
        if (xhr.readyState == 4) {
          const res = JSON.parse(xhr.responseText);
          if (res) {
            events = events.filter(
              (u) => u.event_name != target.dataset["eventName"]
            );
            generatorEventHtml(events);
          }
        }
      };
      xhr.send();
      break;
    ////do the same in the staff table
    case "delStaff":
      xhr.open(
        "get",
        `http://localhost:5500/delStaffById?staffId=${target.dataset["id"]}`
      );
      xhr.onreadystatechange = function () {
        if (xhr.readyState == 4) {
          const res = JSON.parse(xhr.responseText);
          if (res) {
            staffs = staffs.filter((u) => u.staff_id != target.dataset["id"]);
            generatorStaffHtml(staffs);
          }
        }
      };
      xhr.send();
      break;
    default:
      break;
  }
});
//add the listener to the three table name button
document.querySelector("#user").addEventListener("click", generatorUserHtml);
document.querySelector("#staff").addEventListener("click", generatorStaffHtml);
document.querySelector("#events").addEventListener("click", generatorEventHtml);
//creat the HTTP request
//get the data of the getusers case in the server.js
function getusers() {
  const xhr = new XMLHttpRequest();
  xhr.open("get", `http://localhost:5500/getusers`);
  xhr.onreadystatechange = function () {
    if (xhr.readyState == 4) {
      const res = JSON.parse(xhr.responseText);
      // console.log(111, res);
      if (res) {
        users = res.msg;
        generatorUserHtml();
      }
    }
  };
  xhr.send();
}
//creat the HTTP request
//get the data of the getevents case in the server.js
function getevents() {
  const xhr = new XMLHttpRequest();
  xhr.open("get", `http://localhost:5500/getevents`);
  xhr.onreadystatechange = function () {
    if (xhr.readyState == 4) {
      const res = JSON.parse(xhr.responseText);
      // console.log(222, res);
      if (res) {
        events = res.msg;
        // generatorEventHtml();
      }
    }
  };
  xhr.send();
}
//creat the HTTP request
//get the data of the getstaffs case in the server.js
function getstaffs() {
  const xhr = new XMLHttpRequest();
  xhr.open("get", `http://localhost:5500/getstaffs`);
  xhr.onreadystatechange = function () {
    if (xhr.readyState == 4) {
      const res = JSON.parse(xhr.responseText);
      // console.log(333, res);
      if (res) {
        staffs = res.msg;
        // generatorStaffHtml();
      }
    }
  };
  xhr.send();
}

// create the user table in the html
function generatorUserHtml() {
  const tableHeader = `<table class="users">
                              <thead>
                                <tr>
                                  <td style="width:200px">uid</td>
                                  <td style="width:200px">uname</td>
                                  <td style="width:200px">操作</td>
                                </tr>
                              </thead>
                              <tbody>`;

  let trs = "";
  users.forEach((user) => {
    trs += `
                <tr>
                  <td>${user.uid}</td>
                  <td>${user.uname}</td>
                  <td>
                    <input type="button" class="delUser" data-id="${user.uid}" value="delete">
                  </td>
                </tr>
          `;
  });

  $eventList.innerHTML = tableHeader + trs + `</tbody> </table>`;
}

// create the event table in the html
function generatorEventHtml() {
  const tableHeader = `<table class="users">
                              <thead>
                                <tr>
                                  <td style="width:200px">event_name</td>
                                  <td style="width:200px">Place</td>
                                  <td style="width:200px">description</td>
                                  <td style="width:200px">type</td>
                                  <td style="width:200px">date</td>
                                  <td style="width:200px">uname</td>
                                  <td style="width:200px">操作</td>
                                </tr>
                              </thead>
                              <tbody>`;

  let trs = "";
  events.forEach((event) => {
    trs += `
                <tr>
                  <td>${event.event_name}</td>
                  <td>${event.Place}</td>
                  <td>${event.description}</td>
                  <td>${event.type}</td>
                  <td>${event.date}</td>
                  <td>${event.uname}</td>
                  <td>
                    <input type="button" class="delEvent" data-event-name="${event.event_name}" value="delete">
                  </td>
                </tr>
          `;
  });

  $eventList.innerHTML = tableHeader + trs + `</tbody> </table>`;
}

// create the staff table in the html
function generatorStaffHtml() {
  const tableHeader = `<table class="staffs">
                              <thead>
                                <tr>
                                  <td style="width:200px">staffId</td>
                                  <td style="width:200px">staff name</td>
                                  <td style="width:200px">操作</td>
                                </tr>
                              </thead>
                              <tbody>`;

  let trs = "";
  staffs.forEach((staff) => {
    trs += `
                <tr>
                  <td>${staff.staff_id}</td>
                  <td>${staff.staff_name}</td>
                  <td>
                    <input type="button" class="delStaff" data-id="${staff.staff_id}" value="delete">
                  </td>
                </tr>
          `;
  });

  $eventList.innerHTML = tableHeader + trs + `</tbody> </table>`;
}
