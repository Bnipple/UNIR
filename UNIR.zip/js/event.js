let eventListHtml = {};

//Create a XMLHttpRequest object
//XMLHttpRequest is used to exchange data with the server in the background

const xhr = new XMLHttpRequest();
//creat a HTTP request
xhr.open("get", `http://localhost:5500/eventList`);
//if the state code is changed,the onreadystatechange will call function right immediately.
xhr.onreadystatechange = function () {
  //4:Finish and the data is received
  if (xhr.readyState == 4) {
    //set the res equal to the value from the url
    const res = JSON.parse(xhr.responseText);
    //return the data
    console.log(res);
    if (res) {
      const { UpComingHtml, PastHtml } = generatorEventList(res.msg);

      eventListHtml.upcoming = UpComingHtml;
      eventListHtml.past = PastHtml;
      //the default value is 'upcoming'
      chgEventType("upcoming");
    }
  }
};
xhr.send();

const eventList = document.querySelector(".event_list");

// Change the type and assign the value innerhtml(upcoming dom/past dom)
function chgEventType(type) {
  eventList.innerHTML = eventListHtml[type];
  //add event on 'new event' button
  document.querySelector("#add").addEventListener("click", () => {
    location.href = "../html/form.html";
  });
}

const logout = document.querySelector(".logout");
logout.addEventListener("click", function () {
  window.sessionStorage.removeItem("user");
  location = "login.html";
});

// creat eventlist dom
function generatorEventList(events) {
  let UpComingHtml = "",
    PastHtml = "",
    upcomingData = [],
    pastData = [];

  // the current date
  const now = Date.now();
  //a loop to check the events' date
  events.forEach((ev) => {
    const evDate = new Date(ev.date).getTime();
    //Determines whether the event date is before or after the current date
    if (now > evDate) {
      // past
      pastData.push(ev);
    } else {
      // upcoming
      upcomingData.push(ev);
    }
  });

  // Stitching upcoming dom
  upcomingData.forEach((event) => {
    UpComingHtml += `<div class="event">
                  <div class="cover">
                    <div class="date">${event.date}</div>
                    <img
                      src="${
                        event.img ||
                        "data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAAUAAAAFCAYAAACNbyblAAAAHElEQVQI12P4//8/w38GIAXDIBKE0DHxgljNBAAO9TXL0Y4OHwAAAABJRU5ErkJggg=="
                      }">
                  </div>

                  <div class="btm">
                    <h2>${event.event_name}</h2>
                    <h2>${event.type}</h2>
                    <div>
                      Hosted by ${event.uname}
                    </div>
                  </div>
                </div>`;
  });
  pastData.forEach((event) => {
    PastHtml += `<div class="event">
                  <div class="cover">
                    <div class="date">${event.date}</div>
                    <img
                      src="${
                        event.img ||
                        "data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAAUAAAAFCAYAAACNbyblAAAAHElEQVQI12P4//8/w38GIAXDIBKE0DHxgljNBAAO9TXL0Y4OHwAAAABJRU5ErkJggg=="
                      }">
                  </div>

                  <div class="btm">
                    <h2>${event.event_name}</h2>
                    <h2>${event.type}</h2>
                    <div>
                      Hosted by ${event.uname}
                    </div>
                  </div>
                </div>`;
  });

  //the 'new event' container
  UpComingHtml += `<div class="event" id=" ">
                      <div class="cover add" onclick="window.location.href='form.html'">+ NEW EVENT</div>
                    </div>`;

  PastHtml += `<div class="event" id="add">
                    <div class="cover add" onclick="window.location.href='form.html'">+ NEW EVENT</div>
                  </div>`;

  //show the page
  return {
    UpComingHtml,
    PastHtml,
  };
}
