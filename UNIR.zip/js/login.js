const $login = document.querySelector(".submitBtn");
//add a event on the button
$login.addEventListener("click", function () {
  //get values
  var uname = document.getElementById("uname").value;
  var password = document.getElementById("password").value;
  //Create a XMLHttpRequest object
  //XMLHttpRequest is used to exchange data with the server in the background
  const xhr = new XMLHttpRequest();
  //creat a HTTP request
  xhr.open(
    "get",
    `http://localhost:5500/login?uname=${uname}&password=${password}`
  );
  //if the state code is changed,the onreadystatechange will call function right immediately.
  xhr.onreadystatechange = function () {
    //4:Finish and the data is received
    if (xhr.readyState == 4) {
      //set the res equal to the value from the url
      const res = JSON.parse(xhr.responseText);
      //return the data
      console.log(res);
      if (res) {
        // Successfully login
        //keep the data to session
        window.sessionStorage.setItem(
          "user",
          JSON.stringify({ uid: res.uid, uname: res.uname })
        );
        window.location.href = "../html/event.html";
      }
    }
  };
  //send request
  xhr.send();
});
